({
    sort : function(component, event, helper) {
      let compEvent = component.getEvent('sorted');
      let action = component.get('c.getProducts');
        
        action.setCallback(this, function(response){
            component.set('v.products',response.getReturnValue());
           });
        $A.enqueueAction(action);
        event.setParam('message',component.get('v.products'));
        event.fire();
    }
})
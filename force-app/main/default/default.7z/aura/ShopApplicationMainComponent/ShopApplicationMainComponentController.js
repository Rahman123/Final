({
    init:function(component, event, helper) {

           
   },
    setProducts : function(component,event,helper){
       
        alert('got event');
         component.set('products',event.getParam('message'));
    }
})
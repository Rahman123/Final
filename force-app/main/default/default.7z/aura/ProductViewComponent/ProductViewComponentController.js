({
    init:function(component, event, helper) {

        let action = component.get('c.getProducts');
        
        action.setCallback(this, function(response){
            component.set('v.products',response.getReturnValue());
           });
           $A.enqueueAction(action);
           
   },
   message : function(component,event,helper){
      
   }
})
({
	clear : function(component, event, helper) {
        component.set('v.appAttribute','');
	}
})